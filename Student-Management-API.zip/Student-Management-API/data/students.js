const students = [
    {
        id: 1,
        name: "Aditya",
        age: 20,
        course: "Computer Science"
    },
    {
        id: 2,
        name: "Rahul",
        age: 21,
        course: "Information Technology"
    },
    {
        id: 3,
        name: "Priya",
        age: 20,
        course: "Electronics"
    }
];

export default students;